# Darky — project notes

## Installer behaviour (install.sh / uninstall.sh)
- `set -e` is intentionally NOT used in **either** script. Optional steps run through
  `run_step "name" fn` (warn + continue) so a failed package/network/config write never
  aborts the run. Never reintroduce `set -e`.
- Only fatal stops: `detect_distro` (unsupported distro) and `clone_repo` (git clone failed).
- `install_pkg_silent` refreshes metadata (`pacman -Sy` / `dnf makecache` / `apt update`)
  and retries once before returning 1.
- If the chosen shell (zsh/fish) cannot be installed, the installer falls back to bash.
- No step may loop forever: prompts use a `while true` + `case` that always accepts a
  valid answer, and every helper returns 0 on failure. Keep it that way.

## Terminal state save/restore
- `darky-terminal-state.sh` (repo root, sourced by both scripts) owns the logic:
  `darky_save_terminal_state`, `darky_state_get`, `darky_restore_terminal_state`,
  `darky_detect_current_terminal`, `darky_save_theme_snapshot`, `darky_theme_get`,
  `darky_restore_theme_only`. Do not duplicate this logic in the scripts.
- `install.sh` calls the save step inside `install_terminal_theme`, right before theming.
  State lives in `~/.config/darky-backup/terminal-state` + `*.darky-orig` snapshots.
  Colour themes go to `~/.config/darky-backup/terminal-themes/` (`themes` key=value file
  plus copies of user `.colorscheme` files).
- The first snapshot wins: re-running the installer never overwrites the original state
  (neither `terminal-state` nor `terminal-themes/themes`).
- `uninstall.sh` restores configs, the Konsole default profile and the ml4w launcher,
  then reopens the previous emulator. `KEEP_STATE=1` (user skipped restore) keeps
  `~/.config/darky-backup` so it can be retried.
- `uninstall.sh --restore-only` (`-r`) restores the terminal and removes nothing;
  `--help` prints usage. Unknown flags are ignored, never fatal.
- Inside the restore step the user can pick "colours only" (`darky_restore_theme_only`)
  to keep the rest of the themed config.
- The module must stay safe under `set -u`: always use `${VAR:-}` for env vars.

## Fastfetch logo
- `apply_fastfetch_logo` writes a **literal** `~/.config/fastfetch/bat.txt` into
  `config.jsonc` on purpose — fastfetch expands `~` itself. The `SC2088` shellcheck
  warning is silenced with a directive; do not "fix" it to `$HOME`.

## Rounded corners
- The `matinlotfali/KDE-Rounded-Corners` COPR was removed on purpose (user request).
  KDE now only toggles built-in Breeze rounding via `kwriteconfig`; Hyprland uses
  `decoration { rounding = 10 }` in `~/.config/hypr/darky.conf`.
- `uninstall.sh` still removes a leftover `kwin-effect-roundcorners` package if present.

## Verify
- Syntax check: `bash -n install.sh && bash -n uninstall.sh && bash -n darky-terminal-state.sh`
- No `set -e`: `grep -n '^set -e' install.sh uninstall.sh` must print nothing.
- Lint (clean at `-S warning`): `shellcheck -S warning install.sh uninstall.sh darky-terminal-state.sh`
- Scripts must stay executable (`chmod +x`); run them as `./uninstall.sh --restore-only`.
